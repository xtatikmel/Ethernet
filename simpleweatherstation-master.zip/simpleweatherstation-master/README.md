# simpleweatherstation
A simple weather station based on Arduino platform. Componenets used in this project are Arduino Mega 2560, w5100 Ethernet Shield and DHT 11 for temperature and humidity. 
