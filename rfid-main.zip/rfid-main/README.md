# Leitor RFID

Projeto desenvolvido para calculo de horas de inicio e fim de uma entrega.
Todos os dados coletados são enviados para website.

### 📋 Pré-requisitos

Arduino
Ethernet Shield W5100
KIT RFID MFRC522



