# arduino-dht-ethernet
Arduino sketch for Arduino UNO R3 + DHT11 + Ethernet shield W5100 to to php


## libs
http://www.nongnu.org/avr-libc/
