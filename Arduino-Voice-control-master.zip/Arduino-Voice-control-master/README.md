# Arduino-Voice-control
Voice control for Arduino with Ethernet shield Wiznet W5100. Working under HTTP protocol. Voice control with HTTPS. You need 2 variant website.
