# DualDHTthermostat
2x DHTxx's/ATmega2560/W5100
