# W5100-Eventos
Event Monitoring by W5100 Ethernet Shield Arduino

This project receive data from rain drop sensor installed on Arduino / Ethernet Shield W5100. The event data occurred are sended to Data Base Website, using phpMyAdmin and SQL. These resources are available on Free Web Hosting 000webhost.com. 
