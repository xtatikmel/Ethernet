# W5100-Template
Kicad Template for the W5100 Ehternet controller , with SPI enabled and RJ45 Port, implementing hierarchical pins.
